import SwiftUI

struct ArticlesView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        NavigationStack {
            List {
                Section {
                    NavigationLink {
                        MastheadEditor()
                    } label: {
                        HStack {
                            Image(systemName: "textformat.size")
                                .foregroundStyle(.white)
                                .frame(width: 30, height: 30)
                                .background(Color(red: 0.69, green: 0.16, blue: 0.12))
                                .clipShape(RoundedRectangle(cornerRadius: 7))
                            VStack(alignment: .leading, spacing: 2) {
                                Text("报头信息").font(.body.weight(.medium))
                                Text(store.data.masthead.name)
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                } header: {
                    Text("版头")
                }

                Section {
                    ForEach(ArticleSlot.allCases) { slot in
                        NavigationLink {
                            ArticleEditor(slot: slot)
                        } label: {
                            let a = store.article(slot)
                            HStack(spacing: 10) {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(slot.title).font(.caption).foregroundStyle(.secondary)
                                    Text(a.title.isEmpty ? "（未填写标题）" : a.title)
                                        .font(.body.weight(.medium))
                                        .lineLimit(1)
                                    Text(summary(a))
                                        .font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                                }
                                Spacer()
                                Text("\(a.wordCount)字")
                                    .font(.caption2.monospacedDigit())
                                    .foregroundStyle(.tertiary)
                            }
                            .padding(.vertical, 3)
                        }
                    }
                } header: {
                    Text("稿件")
                } footer: {
                    Text("共 \(totalWords) 字。点栏目进入编辑；正文空行分段，「Q/A」开头的行会自动排成问答体。")
                }
            }
            .navigationTitle("班报工作台")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private var totalWords: Int {
        ArticleSlot.allCases.reduce(0) { $0 + store.article($1).wordCount }
    }

    private func summary(_ a: Article) -> String {
        let first = a.body.split(separator: "\n").first.map(String.init) ?? ""
        return first.isEmpty ? "尚未开始写作" : first
    }
}

// MARK: - 报头编辑
struct MastheadEditor: View {
    @EnvironmentObject var store: Store

    var body: some View {
        Form {
            Section("报名") {
                TextField("报名", text: $store.data.masthead.name)
            }
            Section("版头文字") {
                TextField("眉题", text: $store.data.masthead.line1)
                TextField("学校", text: $store.data.masthead.line2)
                TextField("主办", text: $store.data.masthead.line3)
            }
            Section("出版信息") {
                TextField("期号", text: $store.data.masthead.issue)
                TextField("日期", text: $store.data.masthead.date)
                TextField("主编 / 美编", text: $store.data.masthead.editor)
                TextField("指导老师", text: $store.data.masthead.teacher)
            }
            Section("导读") {
                TextEditor(text: $store.data.masthead.lead)
                    .frame(minHeight: 70)
            }
            Section("口号") {
                TextField("班级口号", text: $store.data.masthead.slogan)
            }
            Section {
                Text("报名用行楷字体排版，建议 3–5 字，字数过多会挤压左右信息栏。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("报头信息")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - 单篇编辑
struct ArticleEditor: View {
    @EnvironmentObject var store: Store
    let slot: ArticleSlot

    var body: some View {
        let binding = store.binding(for: slot)
        Form {
            Section {
                TextField("标题", text: binding.title, axis: .vertical)
                    .font(.headline)
                TextField("副标题", text: binding.subtitle, axis: .vertical)
                TextField("署名", text: binding.byline)
            } footer: {
                Text(slot.hint)
            }

            Section("正文") {
                TextEditor(text: binding.body)
                    .frame(minHeight: 320)
                    .font(.system(size: 16, design: .serif))
            }

            Section {
                HStack {
                    Text("字数")
                    Spacer()
                    Text("\(binding.wrappedValue.wordCount)")
                        .monospacedDigit()
                }
                .font(.footnote)
                .foregroundStyle(.secondary)
            }
        }
        .navigationTitle(slot.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
