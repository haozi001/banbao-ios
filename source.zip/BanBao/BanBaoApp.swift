import SwiftUI

@main
struct BanBaoApp: App {
    @StateObject private var store = Store.shared

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .preferredColorScheme(.light)
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            ArticlesView()
                .tabItem { Label("稿件", systemImage: "doc.text") }
            MaterialsView()
                .tabItem { Label("素材", systemImage: "photo.on.rectangle.angled") }
            NewspaperView()
                .tabItem { Label("报纸", systemImage: "newspaper") }
        }
        .tint(Color(red: 0.69, green: 0.16, blue: 0.12))
    }
}
