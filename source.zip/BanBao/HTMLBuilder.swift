import Foundation
import UIKit

struct HTMLBuilder {

    static func build(_ data: Newspaper) -> String {
        let m = data.masthead
        let headline = article(data, .headline)
        let feature  = article(data, .feature)
        let comment  = article(data, .comment)
        let interview = article(data, .interview)
        let sidelight = article(data, .sidelight)
        let postscript = article(data, .postscript)

        let slots = Dictionary(uniqueKeysWithValues: data.photos.map { ($0.id, $0) })
        let dir = Store.shared.photosDir

        var html = """
<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=1123">
<style>
@page { size: 297mm 420mm; margin: 0; }
* { margin:0; padding:0; box-sizing:border-box; }
body { background:#e9e9e9; font-family:"Songti SC","STSong",serif; color:#1a1a1a; }
.page { width:297mm; height:420mm; padding:11mm 12mm 10mm; background:#fdfcf8;
        position:relative; overflow:hidden; margin:0 auto 8mm; page-break-after:always; }
.page:last-child { page-break-after:auto; }

/* 报头 */
.masthead { border-bottom:1.2mm solid #b02a1e; padding-bottom:2.5mm; }
.mh-top { display:flex; align-items:stretch; height:34mm; }
.mh-left { width:52mm; display:flex; flex-direction:column; justify-content:space-between; padding-top:2mm; }
.mh-left .l1 { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:4.2mm; letter-spacing:1.5mm; font-weight:bold; }
.mh-left .l2 { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:3.1mm; letter-spacing:.4mm; color:#666; line-height:1.8; }
.mh-name { flex:1; text-align:center; font-family:"Xingkai SC","Kaiti SC",serif; font-size:28mm;
           line-height:34mm; color:#b02a1e; letter-spacing:4mm; text-indent:4mm; white-space:nowrap; }
.mh-right { width:56mm; text-align:right; font-family:"Heiti SC","PingFang SC",sans-serif; display:flex; flex-direction:column; justify-content:space-between; padding-top:2mm; }
.mh-right .xh { font-size:3.5mm; color:#b02a1e; font-weight:bold; letter-spacing:.4mm; }
.mh-right .info { font-size:3mm; line-height:1.8; color:#333; }
.mast-foot { display:flex; justify-content:space-between; align-items:center; border-top:.4mm solid #b02a1e;
             margin-top:2.2mm; padding-top:1.6mm; font-family:"Heiti SC","PingFang SC",sans-serif; font-size:3mm; }
.mast-foot b { color:#b02a1e; }

/* 通用 */
.cols { display:flex; gap:5mm; margin-top:4mm; height:calc(100% - 46mm); }
.vline { width:.3mm; background:#2b2b2b; }
.kicker { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:3.2mm; color:#b02a1e; text-align:center; letter-spacing:1mm; font-weight:bold; }
h1.head { font-size:12.5mm; text-align:center; line-height:1.22; letter-spacing:1.5mm; font-weight:900; margin:2.5mm 0 1.5mm; }
h2.sub { font-size:3.9mm; text-align:center; font-weight:400; letter-spacing:.3mm; margin-bottom:1.5mm; }
.byline { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:2.9mm; text-align:center; color:#666; margin-bottom:2mm; }
p.body { font-size:3.5mm; line-height:1.78; text-align:justify; text-indent:2em; margin-bottom:1.6mm; }
.lead { font-size:3.7mm; line-height:1.8; text-align:justify; text-indent:2em; margin-bottom:2mm; }

h2.sec { font-size:5.4mm; font-weight:900; letter-spacing:.8mm; border-left:1.6mm solid #b02a1e;
         border-bottom:.4mm solid #b02a1e; padding:.8mm 0 .8mm 2.5mm; margin:3mm 0 2mm; }
h2.sec small { font-size:2.9mm; color:#666; font-weight:400; letter-spacing:.3mm; margin-left:2mm;
               font-family:"Heiti SC","PingFang SC",sans-serif; }
h3.t { font-size:4.4mm; text-align:center; line-height:1.4; margin-bottom:1.4mm; }

/* 图片 */
.ph { border:.4mm dashed #9a9a9a; background:#eeeeee; display:flex; flex-direction:column;
      align-items:center; justify-content:center; color:#7a7a7a; overflow:hidden; }
.ph .tag { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:3mm; text-align:center; line-height:1.6; padding:0 3mm; }
.ph .rt { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:2.6mm; color:#9a9a9a; margin-top:1mm; }
img.pic { width:100%; height:100%; object-fit:cover; display:block; }
.cap { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:2.7mm; color:#666; line-height:1.5; margin-top:1.2mm; }

/* 简报框 */
.brief { border:.5mm solid #2b2b2b; padding:2.5mm 3mm; background:#fbf6ee; }
.brief h4 { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:3.5mm; color:#b02a1e;
            letter-spacing:1mm; border-bottom:.3mm solid #8a6d1f; padding-bottom:1.2mm; margin-bottom:1.4mm; }
.brief li { font-size:3.1mm; line-height:1.7; margin:0 0 1.2mm 5mm; }

/* 数据 */
.stats { display:flex; gap:2mm; }
.stat { flex:1; border:.4mm solid #b02a1e; text-align:center; padding:1.8mm 0; background:#fdf3f0; }
.stat .n { font-size:6mm; font-weight:900; color:#b02a1e; line-height:1.2; }
.stat .t { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:2.6mm; color:#555; }

/* 引语 */
.quote { border-left:1.2mm solid #8a6d1f; background:#faf7ef; padding:2.5mm 3mm; font-size:3.2mm; line-height:1.75; text-align:justify; }
.quote .who { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:2.8mm; color:#8a6d1f; text-align:right; margin-top:1.2mm; }

/* 名单 */
.staff { border-top:.8mm double #b02a1e; margin-top:2.6mm; padding-top:1.6mm;
         font-family:"Heiti SC","PingFang SC",sans-serif; font-size:2.8mm; line-height:1.8;
         display:flex; justify-content:space-between; color:#333; }
.pageno { position:absolute; bottom:6mm; left:0; right:0; text-align:center;
          font-family:"Heiti SC","PingFang SC",sans-serif; font-size:2.8mm; color:#888; letter-spacing:1mm; }

/* 第2版 */
.p2head { display:flex; align-items:baseline; justify-content:space-between;
          border-bottom:1mm solid #b02a1e; padding-bottom:1.8mm; }
.p2head .ban { font-size:7.6mm; font-weight:900; letter-spacing:2mm; color:#b02a1e; }
.p2head .s { font-family:"Heiti SC","PingFang SC",sans-serif; font-size:2.9mm; color:#666; }
.p2cols { display:flex; gap:5mm; margin-top:4mm; height:calc(100% - 30mm); }
.col { flex:1; display:flex; flex-direction:column; }

@media print {
  body { background:#fff; }
  .page { height:418mm; margin:0 auto; box-shadow:none; }
}
</style></head><body>

<!-- ========== 第 1 版 ========== -->
<div class="page">
  <div class="masthead">
    <div class="mh-top">
      <div class="mh-left">
        <div class="l1">\(esc(m.line1))</div>
        <div><div class="l2">\(esc(m.line2))</div><div class="l2">\(esc(m.line3))</div></div>
      </div>
      <div class="mh-name">\(esc(m.name))</div>
      <div class="mh-right">
        <div class="xh">\(esc(m.issue))</div>
        <div class="info">\(esc(m.date))　今日出刊 1-2 版<br>\(esc(m.editor))<br>\(esc(m.teacher))</div>
      </div>
    </div>
    <div class="mast-foot">
      <div><b>导读：</b>\(esc(m.lead))</div>
      <div><b>\(esc(m.slogan))</b></div>
    </div>
  </div>

  <div class="cols">
    <div style="width:33%; display:flex; flex-direction:column; gap:3mm;">
      \(photo("p1", "118mm", slots: slots, dir: dir))
      \(caption("p1", slots: slots))
      \(photo("p2", "62mm", slots: slots, dir: dir))
      <div class="brief" style="flex:1;">
        <h4>第 1 版 · 要闻速览</h4>
        <li>本届校运会共设赛项 __ 项，我班参赛运动员 __ 人次；</li>
        <li>我班代表队在 __ 项目中取得年级前列成绩；</li>
        <li>开幕式团体操亮相，我班 __ 名同学参演；</li>
        <li>班级志愿小队全程护航，累计服务 __ 小时；</li>
        <li>更多精彩瞬间与幕后故事，见第 2 版。</li>
      </div>
    </div>

    <div style="width:67%; display:flex; flex-direction:column;">
      <div class="kicker">—— 聚焦校运 · 新闻实践 ——</div>
      <h1 class="head">\(esc(headline.title))</h1>
      <h2 class="sub">\(esc(headline.subtitle))</h2>
      <div class="byline">\(esc(headline.byline))</div>
      \(paras(headline.body, cls: "lead", limit: 1))
      \(paras(headline.body, cls: "body", skip: 1))
      <div class="stats" style="margin-top:1mm;">
        <div class="stat"><div class="n">__</div><div class="t">比赛项目</div></div>
        <div class="stat"><div class="n">__</div><div class="t">我班运动员</div></div>
        <div class="stat"><div class="n">__</div><div class="t">稿件总数</div></div>
        <div class="stat"><div class="n">__</div><div class="t">现场照片</div></div>
      </div>
      <div style="display:flex; gap:4mm; margin-top:3.5mm;">
        <div style="flex:1.15;">\(photo("p3", "70mm", slots: slots, dir: dir))\(caption("p3", slots: slots))</div>
        <div style="flex:.85;">
          <div class="quote" style="height:100%;">
            \(esc(quoteLine(data)))<div class="who">—— \(esc(quoteWho(data)))</div>
          </div>
        </div>
      </div>
      <div style="flex:1; margin-top:3.5mm; min-height:55mm;">\(photo("p4", "100%", slots: slots, dir: dir))</div>
    </div>
  </div>

  <div class="staff">
    <div><b>【采访组】</b>组长：______　组员：__________</div>
    <div><b>【编写组】</b>组长：______　组员：__________</div>
    <div><b>【摄影组】</b>组长：______　组员：__________</div>
  </div>
  <div class="pageno">第 1 版 · 要闻　◆　\(esc(m.name))　◆　\(esc(m.line3))</div>
</div>

<!-- ========== 第 2 版 ========== -->
<div class="page">
  <div class="p2head">
    <div class="ban">赛场特写 · 人物 · 幕后</div>
    <div class="s">\(esc(m.name)) · 第 2 版 ｜ \(esc(m.date))</div>
  </div>

  <div class="p2cols">
    <div class="col">
      <h2 class="sec">新闻特写 <small>\(esc(feature.subtitle))</small></h2>
      <h3 class="t">《\(esc(feature.title))》</h3>
      <div class="byline">\(esc(feature.byline))</div>
      \(paras(feature.body, cls: "body"))
      <div style="margin-top:2.5mm;">\(photo("p5", "92mm", slots: slots, dir: dir))\(caption("p5", slots: slots))</div>
      <h2 class="sec">人物专访 <small>对话</small></h2>
      <h3 class="t">《\(esc(interview.title))》</h3>
      \(qa(interview.body))
    </div>

    <div class="vline"></div>

    <div class="col">
      <h2 class="sec">新闻评论 <small>本报评论员</small></h2>
      <h3 class="t">《\(esc(comment.title))》</h3>
      <div class="byline">\(esc(comment.byline))</div>
      \(paras(comment.body, cls: "body"))
      <h2 class="sec">幕后花絮 <small>镜头之外</small></h2>
      \(paras(sidelight.body, cls: "body"))
      <div style="display:flex; gap:2.5mm; margin-top:2mm;">
        <div style="flex:1;">\(photo("p7", "52mm", slots: slots, dir: dir))</div>
        <div style="flex:1;">\(photo("p8", "52mm", slots: slots, dir: dir))</div>
      </div>
      <div style="display:flex; gap:2.5mm; margin-top:2.5mm;">
        <div style="flex:1;">\(photo("p9", "52mm", slots: slots, dir: dir))</div>
        <div style="flex:1;">\(photo("p10", "52mm", slots: slots, dir: dir))</div>
      </div>
      <div class="cap">▲ 花絮四宫格：每张配一句俏皮图说。</div>
    </div>

    <div class="vline"></div>

    <div class="col">
      <h2 class="sec">捷 报 <small>我班成绩榜</small></h2>
      <div class="brief" style="background:#fdf3f0; border-color:#b02a1e;">
        <h4 style="border-color:#b02a1e;">拾贰班荣誉时刻</h4>
        <li>男子100米　第__名　______</li>
        <li>女子800米　第__名　______</li>
        <li>4×100米接力　第__名　______</li>
        <li>跳远／实心球　第__名　______</li>
        <li>精神文明奖／最佳方阵（如有）</li>
      </div>
      <div style="flex:1; margin-top:3mm; min-height:110mm;">\(photo("p6", "100%", slots: slots, dir: dir))\(caption("p6", slots: slots))</div>
      <h2 class="sec">编 后 <small>写在最后</small></h2>
      \(paras(postscript.body, cls: "body"))
      <div class="brief" style="margin-top:2mm; background:#f4efe6; text-align:center; padding:4mm 3mm;">
        <div style="font-family:'Heiti SC',sans-serif; font-size:2.9mm; color:#7a7a7a; line-height:1.7;">
          班级口号 / 班徽 / 手绘插画<br>（体现班级特色与班风）
        </div>
      </div>
    </div>
  </div>

  <div class="staff">
    <div><b>总编辑：</b>______　<b>版面设计：</b>______</div>
    <div><b>校对：</b>______　<b>供图：</b>__________</div>
    <div><b>\(esc(m.teacher))</b></div>
  </div>
  <div class="pageno">第 2 版 · 特写 · 评论 · 幕后　◆　\(esc(m.name))　◆　\(esc(m.line3))</div>
</div>
</body></html>
"""
        return html
    }

    // MARK: - 片段

    private static func article(_ data: Newspaper, _ slot: ArticleSlot) -> Article {
        data.articles.first(where: { $0.id == slot.rawValue })
        ?? Article(id: slot.rawValue, title: "", subtitle: "", byline: "", body: "")
    }

    private static func quoteLine(_ data: Newspaper) -> String {
        let text = article(data, .interview).body
        for line in text.split(separator: "\n") where line.hasPrefix("A") {
            let v = line.replacingOccurrences(of: "A：", with: "").trimmingCharacters(in: .whitespaces)
            if !v.isEmpty && v != "______" { return "“\(v)”" }
        }
        return "“______（此处放一句现场最有感染力的原话，需经受访者确认。）”"
    }

    private static func quoteWho(_ data: Newspaper) -> String {
        let a = article(data, .interview)
        return a.subtitle.isEmpty ? "受访者" : a.subtitle
    }

    private static func paras(_ body: String, cls: String, limit: Int = 0, skip: Int = 0) -> String {
        var lines = body.split(separator: "\n", omittingEmptySubsequences: true)
            .map { String($0).trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        if skip > 0 { lines = Array(lines.dropFirst(skip)) }
        if limit > 0 { lines = Array(lines.prefix(limit)) }
        return lines.map { "<p class=\"\(cls)\">\(esc($0))</p>" }.joined()
    }

    private static func qa(_ body: String) -> String {
        let lines = body.split(separator: "\n", omittingEmptySubsequences: true)
            .map { String($0).trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }

        var out = ""
        for line in lines {
            if line.hasPrefix("Q") {
                out += "<p style=\"font-size:3.3mm;font-weight:bold;color:#b02a1e;line-height:1.6;margin-top:1.6mm;\">\(esc(line))</p>"
            } else if line.hasPrefix("A") {
                out += "<p style=\"font-size:3.2mm;line-height:1.75;text-align:justify;\">\(esc(line))</p>"
            } else {
                out += "<p class=\"body\">\(esc(line))</p>"
            }
        }
        return out
    }

    private static func caption(_ id: String, slots: [String: PhotoSlot]) -> String {
        let text = slots[id]?.caption ?? ""
        return "<div class=\"cap\">▲ \(esc(text))</div>"
    }

    private static func photo(_ id: String, _ height: String,
                              slots: [String: PhotoSlot], dir: URL) -> String {
        let slot = slots[id]
        let name = slot?.name ?? "图片占位"
        let ratio = slot?.ratio ?? ""
        let style = "height:\(height);"

        if let filename = slot?.filename,
           let raw = try? Data(contentsOf: dir.appendingPathComponent(filename)),
           let img = UIImage(data: raw) {
            // 直接内嵌 base64，避免 WKWebView 读取本地文件路径失败
            if let jpeg = img.jpegData(compressionQuality: 0.82) {
                let b64 = jpeg.base64EncodedString()
                return "<div class=\"ph\" style=\"\(style)border:none;background:none;\"><img class=\"pic\" src=\"data:image/jpeg;base64,\(b64)\"></div>"
            }
        }
        return """
        <div class="ph" style="\(style)">
          <div class="tag">\(esc(name))</div>
          <div class="rt">\(esc(ratio))</div>
        </div>
        """
    }

    static func esc(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
    }
}
