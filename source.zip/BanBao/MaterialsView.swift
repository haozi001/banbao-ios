import SwiftUI
import PhotosUI
import UIKit

struct MaterialsView: View {
    @EnvironmentObject var store: Store
    @State private var editing: PhotoSlot?

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                    ForEach(store.data.photos) { slot in
                        SlotCard(slot: slot) {
                            editing = slot
                        }
                    }
                }
                .padding(12)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("素材")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(item: $editing) { slot in
                SlotEditor(slotID: slot.id)
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Text("\(filledCount)/\(store.data.photos.count)")
                        .font(.footnote.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var filledCount: Int {
        store.data.photos.filter { $0.filename != nil }.count
    }
}

struct SlotCard: View {
    @EnvironmentObject var store: Store
    let slot: PhotoSlot
    let onEdit: () -> Void

    var body: some View {
        Button(action: onEdit) {
            VStack(alignment: .leading, spacing: 6) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color(.secondarySystemBackground))
                    if let img = store.image(for: slot) {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                            .frame(height: 118)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    } else {
                        VStack(spacing: 6) {
                            Image(systemName: "photo.on.rectangle.angled")
                                .font(.title3)
                                .foregroundStyle(.secondary)
                            Text(slot.ratio)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        .frame(height: 118)
                    }
                }
                .frame(height: 118)
                .clipped()

                Text(slot.name)
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                Text(slot.caption)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .frame(height: 30, alignment: .top)
            }
            .padding(8)
            .background(Color(.systemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }
}

struct SlotEditor: View {
    @EnvironmentObject var store: Store
    let slotID: String
    @Environment(\.dismiss) private var dismiss

    @State private var pickerItem: PhotosPickerItem?
    @State private var caption: String = ""
    @State private var loaded = false

    var body: some View {
        NavigationStack {
            Form {
                if let idx = store.data.photos.firstIndex(where: { $0.id == slotID }) {
                    Section {
                        if let img = store.image(for: store.data.photos[idx]) {
                            Image(uiImage: img)
                                .resizable()
                                .scaledToFit()
                                .frame(maxHeight: 260)
                                .frame(maxWidth: .infinity)
                        } else {
                            VStack(spacing: 8) {
                                Image(systemName: "photo")
                                    .font(.largeTitle)
                                    .foregroundStyle(.tertiary)
                                Text("尚未选择照片")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity, minHeight: 140)
                        }

                        PhotosPicker(selection: $pickerItem, matching: .images) {
                            Label("从相册选择", systemImage: "photo.on.rectangle")
                        }

                        if store.data.photos[idx].filename != nil {
                            Button(role: .destructive) {
                                store.removeImage(from: slotID)
                            } label: {
                                Label("移除这张照片", systemImage: "trash")
                            }
                        }
                    } header: {
                        Text("\(store.data.photos[idx].name)（\(store.data.photos[idx].ratio)）")
                    }

                    Section("图说") {
                        TextField("一句话图说：谁、在哪、什么动作、什么结果", text: $caption, axis: .vertical)
                            .lineLimit(2...4)
                    }
                }
            }
            .navigationTitle("导入素材")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") {
                        saveCaption()
                        dismiss()
                    }
                    .bold()
                }
            }
            .onAppear {
                if !loaded {
                    caption = store.photo(slotID)?.caption ?? ""
                    loaded = true
                }
            }
            .onDisappear { saveCaption() }
            .onChange(of: pickerItem) { newValue in
                guard let newValue else { return }
                Task {
                    if let data = try? await newValue.loadTransferable(type: Data.self) {
                        await MainActor.run {
                            store.importImage(data: data, into: slotID)
                            pickerItem = nil
                        }
                    }
                }
            }
        }
    }

    private func saveCaption() {
        if let idx = store.data.photos.firstIndex(where: { $0.id == slotID }) {
            store.data.photos[idx].caption = caption
        }
    }
}
