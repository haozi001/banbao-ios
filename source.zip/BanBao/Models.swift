import Foundation

// MARK: - 稿件栏目
enum ArticleSlot: String, Codable, CaseIterable, Identifiable {
    case headline, feature, comment, interview, sidelight, postscript

    var id: String { rawValue }

    var title: String {
        switch self {
        case .headline:   return "头版头条"
        case .feature:    return "新闻特写"
        case .comment:    return "新闻评论"
        case .interview:  return "人物专访"
        case .sidelight:  return "幕后花絮"
        case .postscript: return "编后记"
        }
    }

    var hint: String {
        switch self {
        case .headline:   return "消息：导语先交代 5W，再展开细节，标题要有动词。"
        case .feature:    return "特写：抓一个瞬间放大慢写，写声音、动作、表情。"
        case .comment:    return "评论：由现场切入，亮观点，再论证，最后落到班级。"
        case .interview:  return "专访：一问一答，保留口语感，问题要有针对性。"
        case .sidelight:  return "花絮：写镜头外的小事，越具体越好看。"
        case .postscript: return "编后记：编辑部口吻收尾，感谢与呼应主题。"
        }
    }
}

struct Article: Codable, Identifiable, Hashable {
    var id: String            // 使用 slot.rawValue
    var title: String
    var subtitle: String
    var byline: String
    var body: String

    var wordCount: Int {
        body.filter { !$0.isWhitespace && !$0.isNewline }.count
    }
}

// MARK: - 图片槽位
struct PhotoSlot: Codable, Identifiable, Hashable {
    var id: String
    var name: String
    var caption: String
    var filename: String?     // Documents/photos/ 下的文件名
    var ratio: String         // 提示用，例如 "4:3 横版"
    var big: Bool             // 是否大图槽位
}

// MARK: - 报头
struct Masthead: Codable {
    var name: String = "拾贰看台"
    var line1: String = "校园新闻实践特刊"
    var line2: String = "漳州一中芝山校区"
    var line3: String = "八年（12）班新闻中心 主办"
    var issue: String = "第 三 届 · 校 运 会 特 刊　总第 01 期"
    var date: String = "2026年11月20日 星期五"
    var editor: String = "执行主编：______　美编：______"
    var teacher: String = "指导老师：吕海华"
    var slogan: String = "运动会里做新闻 · 班报设计活动"
    var lead: String = "① 开幕式全景 —— 第1版 ｜ ② 百米飞人大战特写 —— 第2版 ｜ ③ 班主任专访 —— 第2版"
}

// MARK: - 整份报纸
struct Newspaper: Codable {
    var masthead: Masthead = Masthead()
    var articles: [Article] = Newspaper.defaultArticles()
    var photos: [PhotoSlot] = Newspaper.defaultPhotos()

    static func defaultArticles() -> [Article] {
        [
            Article(id: ArticleSlot.headline.rawValue,
                    title: "芝山秋日燃战鼓　拾贰健儿启新程",
                    subtitle: "——漳州一中芝山校区2026年体育健康节暨秋季运动会开幕侧记",
                    byline: "本报记者　______　发自芝山校区田径场",
                    body: "11月20日上午8时，芝山脚下，国旗猎猎，鼓乐齐鸣。漳州一中芝山校区2026年体育健康节暨秋季运动会正式拉开帷幕。当八年（12）班方阵迈着整齐的步伐走过主席台，响亮的口号响彻操场——属于拾贰班的四十八小时，就此点燃。"),
            Article(id: ArticleSlot.feature.rawValue,
                    title: "那一瞬间，全班都在喊他的名字",
                    subtitle: "定格 9 秒 83 的风",
                    byline: "本报记者　______",
                    body: "枪响之前，看台上安静得能听见风。\n他蹲在起跑器上，指尖抵着塑胶跑道，指节泛白。第三道，第八个赛季，第一次站在决赛的起跑线上。"),
            Article(id: ArticleSlot.comment.rawValue,
                    title: "跑道终会到头，少年仍在路上",
                    subtitle: "本报评论员文章",
                    byline: "本报评论员　______",
                    body: "运动会只有两天，可有些东西会留在身上很久：起跑时不自觉绷紧的肩，交接棒时那句「稳住」，还有冲线后回头看队友的那一眼。"),
            Article(id: ArticleSlot.interview.rawValue,
                    title: "班主任说：比起名次，我更看重这个",
                    subtitle: "人物专访",
                    byline: "本报记者　______",
                    body: "Q1：您觉得这次运动会，班里最大的变化是什么？\nA：______\n\nQ2：有没有哪个瞬间让您印象特别深？\nA：______\n\nQ3：想对全班同学说点什么？\nA：______"),
            Article(id: ArticleSlot.sidelight.rawValue,
                    title: "镜头之外",
                    subtitle: "幕后花絮",
                    byline: "本报记者　______",
                    body: "后勤组的同学把整箱矿泉水搬到看台时，比赛已经开始了第三项。他们没看到任何一场决赛，却在每一次有人喊渴的时候，第一个站起来。"),
            Article(id: ArticleSlot.postscript.rawValue,
                    title: "写在最后",
                    subtitle: "编后记",
                    byline: "编辑部",
                    body: "这份报纸从策划到付印只用了五天。感谢每一位接受采访的同学和老师，感谢摄影组蹲守了三个小时只为一张冲线照。班班有报纸，人人懂新闻——我们把运动会，做成了一份可以留很久的东西。")
        ]
    }

    static func defaultPhotos() -> [PhotoSlot] {
        [
            PhotoSlot(id: "p1", name: "头版主图·开幕式方阵", caption: "11月20日，八年（12）班方阵走过主席台。", filename: nil, ratio: "4:3 横版", big: true),
            PhotoSlot(id: "p2", name: "裁判员 / 志愿者", caption: "红马甲志愿者在检录处维持秩序。", filename: nil, ratio: "3:2 横版", big: false),
            PhotoSlot(id: "p3", name: "百米起跑瞬间", caption: "男子100米预赛起跑瞬间。", filename: nil, ratio: "3:2 横版", big: false),
            PhotoSlot(id: "p4", name: "啦啦队呐喊", caption: "看台上的加油声一浪高过一浪。", filename: nil, ratio: "16:9 横版", big: false),
            PhotoSlot(id: "p5", name: "特写配图·冲刺 / 腾空", caption: "______同学在跳远比赛中腾空而起。", filename: nil, ratio: "1:1 方图", big: false),
            PhotoSlot(id: "p6", name: "第2版大图·领奖 / 相拥", caption: "______同学夺冠后与同学相拥。", filename: nil, ratio: "3:4 竖版", big: true),
            PhotoSlot(id: "p7", name: "花絮图①", caption: "后勤组递水的瞬间。", filename: nil, ratio: "1:1 方图", big: false),
            PhotoSlot(id: "p8", name: "花絮图②", caption: "摄影组蹲点三小时。", filename: nil, ratio: "1:1 方图", big: false),
            PhotoSlot(id: "p9", name: "花絮图③", caption: "采访本上的提纲。", filename: nil, ratio: "1:1 方图", big: false),
            PhotoSlot(id: "p10", name: "花絮图④", caption: "比赛结束后的看台。", filename: nil, ratio: "1:1 方图", big: false)
        ]
    }
}
