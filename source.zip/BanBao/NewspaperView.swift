import SwiftUI
import WebKit
import UIKit

struct NewspaperView: View {
    @EnvironmentObject var store: Store

    @State private var token = UUID()
    @State private var html: String = ""
    @State private var webView: WKWebView?
    @State private var shareURL: URL?
    @State private var showShare = false
    @State private var busy = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()
                WebContainer(html: html, token: token) { wv in
                    webView = wv
                }
                .ignoresSafeArea(edges: .bottom)

                if busy {
                    ProgressView("正在生成 A3 PDF…")
                        .padding(20)
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
                }
            }
            .navigationTitle("报纸预览")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        rebuild()
                    } label: {
                        Label("刷新", systemImage: "arrow.clockwise")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        exportPDF()
                    } label: {
                        Label("导出", systemImage: "square.and.arrow.up")
                    }
                    .disabled(webView == nil || busy)
                }
            }
            .sheet(isPresented: $showShare) {
                if let url = shareURL {
                    ShareSheet(items: [url])
                }
            }
            .onAppear { if html.isEmpty { rebuild() } }
            .alert("提示", isPresented: Binding(
                get: { message != nil },
                set: { if !$0 { message = nil } }
            )) {
                Button("好", role: .cancel) { message = nil }
            } message: {
                Text(message ?? "")
            }
        }
    }

    private func rebuild() {
        let data = store.data
        DispatchQueue.global(qos: .userInitiated).async {
            let generated = HTMLBuilder.build(data)
            DispatchQueue.main.async {
                html = generated
                token = UUID()
            }
        }
    }

    private func exportPDF() {
        guard let webView else { return }
        busy = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            let result = PDFExporter.export(webView: webView)
            busy = false
            switch result {
            case .success(let url):
                shareURL = url
                showShare = true
            case .failure(let err):
                message = err.localizedDescription
            }
        }
    }
}

// MARK: - WKWebView 容器
struct WebContainer: UIViewRepresentable {
    let html: String
    let token: UUID
    let onReady: (WKWebView) -> Void

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.backgroundColor = UIColor(white: 0.92, alpha: 1)
        webView.scrollView.bounces = true
        webView.navigationDelegate = context.coordinator
        webView.loadHTMLString(html, baseURL: Store.shared.documents)
        context.coordinator.lastToken = token
        let ready = onReady
        DispatchQueue.main.async { ready(webView) }
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        if context.coordinator.lastToken != token {
            context.coordinator.lastToken = token
            webView.loadHTMLString(html, baseURL: Store.shared.documents)
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    final class Coordinator: NSObject, WKNavigationDelegate {
        var lastToken: UUID?
    }
}

// MARK: - 分享面板
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
