import Foundation
import UIKit
import WebKit

enum PDFExporter {

    // A3：297 × 420 mm
    static let a3 = CGRect(x: 0, y: 0, width: 841.89, height: 1190.55)

    enum ExportError: LocalizedError {
        case empty
        case failed(String)

        var errorDescription: String? {
            switch self {
            case .empty: return "页面还没有加载完成，请稍后再试。"
            case .failed(let s): return s
            }
        }
    }

    static func export(webView: WKWebView) -> Result<URL, Error> {
        let formatter = webView.viewPrintFormatter()
        formatter.perPageContentInsets = .zero

        let renderer = UIPrintPageRenderer()
        renderer.addPrintFormatter(formatter, startingAtPageAt: 0)

        // 通过 KVC 设置纸张尺寸（iOS 上常用做法）
        renderer.setValue(NSValue(cgRect: a3), forKey: "paperRect")
        renderer.setValue(NSValue(cgRect: a3), forKey: "printableRect")

        let pages = renderer.numberOfPages
        guard pages > 0 else { return .failure(ExportError.empty) }

        let data = NSMutableData()
        let info: [AnyHashable: Any] = [
            kCGPDFContextTitle as String: "\(Store.shared.data.masthead.name) 班报",
            kCGPDFContextCreator as String: "班报工作台"
        ]
        UIGraphicsBeginPDFContextToData(data, a3, info)
        renderer.prepare(forDrawingPages: NSRange(location: 0, length: pages))
        for i in 0..<pages {
            UIGraphicsBeginPDFPage()
            let bounds = UIGraphicsGetPDFContextBounds()
            renderer.drawPage(at: i, in: bounds)
        }
        UIGraphicsEndPDFContext()

        guard data.length > 0 else { return .failure(ExportError.failed("PDF 生成失败，页面为空。")) }

        let name = Store.shared.data.masthead.name
            .replacingOccurrences(of: "/", with: "-")
        let url = Store.shared.documents.appendingPathComponent("\(name)_A3.pdf")
        do {
            try (data as Data).write(to: url, options: .atomic)
            Store.shared.lastExportedPDF = url
            return .success(url)
        } catch {
            return .failure(ExportError.failed("写入文件失败：\(error.localizedDescription)"))
        }
    }
}
