import Foundation
import SwiftUI
import UIKit

final class Store: ObservableObject {
    static let shared = Store()

    @Published var data: Newspaper = Newspaper() { didSet { scheduleSave() } }
    @Published var lastExportedPDF: URL?

    private var saveWorkItem: DispatchWorkItem?
    let documents: URL
    let photosDir: URL

    private init() {
        documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        photosDir = documents.appendingPathComponent("photos", isDirectory: true)
        try? FileManager.default.createDirectory(at: photosDir, withIntermediateDirectories: true)
        load()
    }

    // MARK: 持久化
    private var dataURL: URL { documents.appendingPathComponent("newspaper.json") }

    private func load() {
        guard let raw = try? Data(contentsOf: dataURL) else { return }
        if let decoded = try? JSONDecoder().decode(Newspaper.self, from: raw) {
            data = decoded
        }
    }

    private func scheduleSave() {
        saveWorkItem?.cancel()
        let snapshot = data
        let url = dataURL
        let item = DispatchWorkItem {
            if let raw = try? JSONEncoder().encode(snapshot) {
                try? raw.write(to: url, options: .atomic)
            }
        }
        saveWorkItem = item
        DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 0.6, execute: item)
    }

    func saveNow() {
        if let raw = try? JSONEncoder().encode(data) {
            try? raw.write(to: dataURL, options: .atomic)
        }
    }

    // MARK: 稿件
    func binding(for slot: ArticleSlot) -> Binding<Article> {
        Binding(
            get: {
                self.data.articles.first(where: { $0.id == slot.rawValue })
                ?? Article(id: slot.rawValue, title: "", subtitle: "", byline: "", body: "")
            },
            set: { newValue in
                if let idx = self.data.articles.firstIndex(where: { $0.id == slot.rawValue }) {
                    self.data.articles[idx] = newValue
                } else {
                    self.data.articles.append(newValue)
                }
            }
        )
    }

    func article(_ slot: ArticleSlot) -> Article {
        data.articles.first(where: { $0.id == slot.rawValue })
        ?? Article(id: slot.rawValue, title: "", subtitle: "", byline: "", body: "")
    }

    // MARK: 图片
    func image(for slot: PhotoSlot) -> UIImage? {
        guard let name = slot.filename else { return nil }
        let url = photosDir.appendingPathComponent(name)
        guard let raw = try? Data(contentsOf: url) else { return nil }
        return UIImage(data: raw)
    }

    func importImage(data raw: Data, into slotID: String) {
        guard let idx = data.photos.firstIndex(where: { $0.id == slotID }) else { return }
        let filename = "\(slotID).jpg"
        let url = photosDir.appendingPathComponent(filename)
        // 压缩到长边 2200px，兼顾印刷清晰度与体积
        if let image = UIImage(data: raw),
           let fixed = image.downsampled(maxDimension: 2200),
           let jpeg = fixed.jpegData(compressionQuality: 0.92) {
            try? jpeg.write(to: url, options: .atomic)
        } else {
            try? raw.write(to: url, options: .atomic)
        }
        data.photos[idx].filename = filename
    }

    func removeImage(from slotID: String) {
        guard let idx = data.photos.firstIndex(where: { $0.id == slotID }) else { return }
        if let name = data.photos[idx].filename {
            try? FileManager.default.removeItem(at: photosDir.appendingPathComponent(name))
        }
        data.photos[idx].filename = nil
    }

    func photo(_ id: String) -> PhotoSlot? {
        data.photos.first(where: { $0.id == id })
    }
}

extension UIImage {
    func downsampled(maxDimension: CGFloat) -> UIImage? {
        let longest = max(size.width, size.height)
        guard longest > maxDimension else { return self }
        let scale = maxDimension / longest
        let newSize = CGSize(width: size.width * scale, height: size.height * scale)
        let renderer = UIGraphicsImageRenderer(size: newSize)
        return renderer.image { _ in
            draw(in: CGRect(origin: .zero, size: newSize))
        }
    }
}
