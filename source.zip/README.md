# 班报工作台 · iOS 版

为「第三届 运动会里做新闻」班报设计活动制作的 iPhone/iPad 应用：
在手机上写稿、导入照片、实时预览 A3 报纸版式，并一键导出可打印的 A3 PDF。

## 功能

| 模块 | 说明 |
|---|---|
| 稿件 | 六大栏目（头版头条 / 特写 / 评论 / 专访 / 花絮 / 编后）逐篇编辑，自动统计字数，Q/A 自动排问答体 |
| 报头 | 报名、期号、日期、主编、指导老师、导读全部可改（报名用行楷大字排版） |
| 素材 | 10 个照片槽位（含比例提示），从相册导入自动压缩到印刷级分辨率，逐张写图说 |
| 报纸 | 内嵌 A3 双版实时预览，未传图自动显示虚线占位框 |
| 导出 | 生成 A3 矢量 PDF，直接通过系统分享面板发送（微信 / 文件 / 打印） |

所有数据保存在本机（Documents/newspaper.json + photos/），无需联网。

## 生成未签名 IPA（两种方式）

### 方式 A：GitHub Actions 云端构建（无 Mac 也可用）

1. 把本文件夹整个上传到一个 GitHub 仓库（注意 `.github` 是隐藏文件夹，压缩包上传或 git push 都可）；
2. 仓库 → Actions → `build-ipa` 工作流会自动运行；
3. 运行完成后在 Artifacts 下载 **BanBao-unsigned-ipa.zip**，解压即得 `BanBao-unsigned.ipa`（未签名）。

> 手动触发：Actions 页面右上角 `Run workflow`。

### 方式 B：本机 Mac 构建

```bash
brew install xcodegen
cd 班报工作台_iOS
xcodegen generate
open BanBao.xcodeproj
# Xcode 中选真机 → Product → Archive → Distribute（不勾选重签）
```

命令行打包未签名 IPA：

```bash
xcodebuild -project BanBao.xcodeproj -scheme BanBao -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGN_IDENTITY="" build
mkdir Payload && cp -R build/Build/Products/Release-iphoneos/BanBao.app Payload/
zip -qry BanBao-unsigned.ipa Payload
```

## 自签名安装

拿到未签名 IPA 后，用你自己的证书重签：

- **Sideloadly / 爱思助手**：导入 IPA → 填 Apple ID（或导入 p12 + mobileprovision）→ 签名安装；
- 签名时 Bundle ID 需与描述文件一致，默认 `com.zhanyu.banbao`，可在 project.yml 里改；
- 证书有效期到期后需重签。

## 工程结构

```
project.yml                # XcodeGen 工程描述（生成 BanBao.xcodeproj）
.github/workflows/         # 云端自动打包未签名 IPA
BanBao/
  BanBaoApp.swift          # 入口 + 三个标签页
  Models.swift             # 稿件/图片槽位/报头数据模型
  Store.swift              # 本地持久化 + 照片管理
  ArticlesView.swift       # 稿件编辑
  MaterialsView.swift      # 素材导入（相册）
  NewspaperView.swift      # A3 实时预览（WKWebView）
  HTMLBuilder.swift        # 报纸 HTML 排版引擎
  PDFExporter.swift        # A3 矢量 PDF 导出
  Assets.xcassets          # 应用图标（毛笔「报」字）
```
